# RentDublinApp Starter

This repository is a simple starter template for the **RentDublinApp** SaaS rental platform.  It contains a minimal monorepo structure with a back‑end built on Node.js/Express and a front‑end mobile app built with React Native.  You can use this as a starting point for further development and add more features such as database integration, authentication, payments, chat, and more.

## Structure

```
new_rentdublinapp/
├── package.json         # root package definition and workspace config
├── README.md            # overview of the project
└── packages/
    ├── backend/
    │   ├── package.json # backend dependencies and scripts
    │   └── index.js     # basic Express server
    └── mobile/
        ├── package.json # mobile dependencies and scripts
        └── App.js       # basic React Native app
```

## Getting Started

1. **Install dependencies**:

   ```bash
   # install pnpm if you don't have it
   npm install -g pnpm

   # install workspace dependencies
   pnpm install
   ```

2. **Run the back‑end server**:

   ```bash
   cd packages/backend
   pnpm start
   ```

   The server will start on port 3000 and respond with “Hello, world!” on the root path.

3. **Run the mobile app**:

   ```bash
   cd packages/mobile
   pnpm start
   ```

   This will launch the Expo development server for the React Native app.  You can open it with the Expo Go app on your phone or an emulator.

This project is meant as a barebones foundation—feel free to expand on it to suit your needs!
